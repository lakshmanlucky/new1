﻿using empbusiness;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;

namespace omr_gropu6
{
    public partial class changemariagcertificate : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

            bindgrid();
        }
        private void bindgrid()
        {
            try
            {
                IBuisness objapp = new clsbuisness();
                DataTable dt = objapp.viewchangereq();
                if (dt != null)
                {
                    if (dt.Rows.Count == 0)
                    {

                        Response.Write("<script>alert('No applications  to display')</script>");
                        GridView1.Visible = false;

                    }
                    else
                    {
                        GridView1.Visible = true;
                        GridView1.DataSource = dt;
                        GridView1.DataBind();

                    }
                }
                else
                {
                    Response.Write("<script>alert('Error in dispalying applications')</script>");


                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           
                if (e.CommandName == "up")
                {
                    GridView1.Visible = false;
                    IBO objbo = new empbobject.clsbo();
                    IBuisness objapp = new clsbuisness();
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    string app = row.Cells[0].Text;

                    objbo.idd = app;
                    
                    DataTable dt = objapp.viewchangevalue(objbo);

                    dvchangevalue.DataSource = dt;
                    dvchangevalue.DataBind();
                    dvchangevalue.Visible = true;
                }

                if (e.CommandName == "generate")
                {

                    if (Session["imp"] != null)
                    {

                        IBO objbo = new empbobject.clsbo();
                        IBuisness objapp = new clsbuisness();
                        int index = Convert.ToInt32(e.CommandArgument);
                        GridViewRow row = GridView1.Rows[index];
                        string app1 = row.Cells[0].Text;
                        string cr = row.Cells[0].Text;
                        string no = cr + 1;

                        if (Session["imp"].ToString() == no)
                        {
                            Session["idd"] = app1;
                            Response.Redirect("Certificate.aspx");
                        }

                        else
                        {
                            Response.Write("<script>alert('update first')</script>");
                            GridView1.Visible = true;
                        }
                    }

                }


           
        }
        protected void dvchangevalue_ItemCommand(object sender, DetailsViewCommandEventArgs e)
        {
            try
            {
                dvchangevalue.Visible = false;
                IBO objbo = new empbobject.clsupdatecertificate();
                IBuisness objapp = new clsbuisness();

                if (e.CommandName == "Up")
                {

                    DetailsViewRow row = dvchangevalue.Rows[0];
                    objbo.idd = row.Cells[1].Text;

                    objbo.col_name = dvchangevalue.Rows[1].Cells[1].Text;
                    objbo.old_val = dvchangevalue.Rows[2].Cells[1].Text;
                    objbo.new_val = dvchangevalue.Rows[3].Cells[1].Text;
                    objbo.statuss = dvchangevalue.Rows[4].Cells[1].Text;
                    objbo.remarkss = dvchangevalue.Rows[5].Cells[1].Text;
                    string app = dvchangevalue.Rows[6].Cells[1].Text;
                    string cr1 = app + 1;
                    Session["imp"] = cr1;
                    int a = objapp.changecertificate(objbo);
                    if (a > 0)
                    {
                        Response.Write("<script>alert('updated succesfully')</script>");
                    }

                }
                if (e.CommandName == "Can")
                {

                    dvchangevalue.Visible = false;

                }
                GridView1.Visible = true;

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }

        }
    }
}