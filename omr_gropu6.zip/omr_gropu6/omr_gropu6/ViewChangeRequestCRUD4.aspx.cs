﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using empbusiness;
using empbobject;
using Types;
using System.Data;
namespace omr_gropu6
{
    public partial class ViewChangeRequestCRUD4 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {try
            {
                p12.Visible = true;
               
                this.UnobtrusiveValidationMode = UnobtrusiveValidationMode.None;

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }

     

        //protected void GridView1_SelectedIndexChanged(object sender, EventArgs e)
        //{
        //    ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Verified successfully');", true);
        //    lblrem.Visible = true;
        //    Label4.Visible = true;
        //    lblapprem.Visible = true;
        //    txtappnorem.Visible = true;
        //    lblrem.Visible = true;
        //    txtrem.Visible = true;
        //    btnfrwd.Visible = true;
        //}
        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {try
            {
                //ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Verified successfully');", true);
                Response.Write("<script>alert('Verified successfully')</script>");
                lblrem.Visible = true;
               
                lblapprem.Visible = true;
                txtappnorem.Visible = true;
                lblrem.Visible = true;
                txtrem.Visible = true;
                btnfrwd.Visible = true;
                if (e.CommandName == "new")
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView1.Rows[index];
                    string requestNo = row.Cells[1].Text;

                    txtappnorem.Text = requestNo;
                    GridView1.Visible = false;
                    p11.Visible = false;
                    p12.Visible = true;
                }
            
               }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
}

        protected void btnfrwd_Click(object sender, EventArgs e)
        {
            try
            { 
            if (!string.IsNullOrEmpty(txtrem.Text))
            {
                viewcrbo bo = new viewcrbo();
                bo.app_no = txtappnorem.Text;
                bo.Remarks = txtrem.Text;
                viewcrbll bl = new viewcrbll();
                bl.forward(bo);
                ClientScript.RegisterClientScriptBlock(this.GetType(), "Verification message", "alert('Remarks added successfully');", true);
                txtappnorem.Text = string.Empty;
                txtrem.Text = string.Empty;
                p11.Visible = true;
                p12.Visible = false;
            }
            else
            {
                Response.Write("<script>alert('please provide remarks')</script>");
            }

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
            //GridView1.DataSource
            //GridView1.DataBind();


        }
       
        protected void btnview_Click(object sender, EventArgs e)
        {
           
                p12.Visible = false;

                GridView1.Visible = true;
         
            IVIEWCRBO objbbo = new empbobject.viewcrbo();

            IVIEWCRBLL objapp = new viewcrbll();
            //string check = bo.app_no.ToString();

            if (!String.IsNullOrEmpty(txtappno.Text))
            {
                objbbo.app_no = txtappno.Text;
            }
            else
            {
                objbbo.app_no = null;
            }
            if (!String.IsNullOrEmpty(txtmrgeloc.Text))
            {
                objbbo.mrgeloc = txtmrgeloc.Text;
            }
            else
            {
                objbbo.mrgeloc = null;
            }
            if (!String.IsNullOrEmpty(txthusbandname.Text))
            {
                objbbo.hname = txthusbandname.Text;
            }
            else
            {
                objbbo.hname = null;
            }
            if (!String.IsNullOrEmpty(txtwname.Text))
            {
                objbbo.wname = txtwname.Text;
            }
            else
            {
                objbbo.wname = null;
            }

            DataTable dt = objapp.ViewbyCR(objbbo);
            if (dt != null)
            {
                if (dt.Rows.Count == 0)
                {
                   
                    Response.Write("<script>alert('No applications  to display')</script>");
                    p12.Visible = true;
                    p11.Visible = true;
                    GridView1.Visible = false;
                  
                }
                else
                {
                   
                    GridView1.DataSource = dt;
                    GridView1.DataBind();
                        GridView1.Visible = true;
                    p11.Visible = false;
                }
                    
            }
            else
            {
                lblmsg.Visible = true;
                lblmsg.Text = "Error in dispalying applications ";
            }
           

          
        }

        protected void txtappnorem_TextChanged(object sender, EventArgs e)
        {
            
                }

        protected void Button1_Click(object sender, EventArgs e)
        {
            try
            { 
            GridView1.Visible = true;
            viewcrbll bl = new viewcrbll();
            p12.Visible = true;
            p11.Visible = true;
            GridView1.DataSource = bl.viewall();
            GridView1.DataBind();

            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
            p12.Visible = false;

        }

        //protected void txtrem_TextChanged(object sender, EventArgs e)
        //{
        //    txtrem.Visible = true;
        //}
        //protected void txtappnorem_TextChanged(object sender, EventArgs e)
        //{
        //    txtrem.Visible = true;
        //}
    }
}