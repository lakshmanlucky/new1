﻿using empbusiness;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Types;

namespace omr_gropu6
{
    public partial class ApproveCR : System.Web.UI.Page
    {
        string status;

        protected void Btn_ViewCR(object sender, EventArgs e)
        {

         
        }
        private void bindgrid()
        {
            try
            {
                IBuisness objapp = new clsbuisness();
                DataTable dt = objapp.Viewallcr();
                if (dt != null)
                {
                    if (dt.Rows.Count == 0)
                    {
                        GridView2.Visible = false;
                        Label4.Visible = true;
                        Label4.Text = "No Change requests  to display";
                    }
                    else
                    {

                        GridView2.DataSource = dt;
                        GridView2.DataBind();
                    }
                }
                else
                {
                    GridView2.Visible = false;
                    Label4.Visible = true;
                    Label4.Text = "Error in dispalying chnge requests ";
                }
            }
            catch (Exception ex)
            {
                Response.Write("<script>alert('something went wrong')</script>");
            }
        }

        protected void GridView1_RowCommand(object sender, GridViewCommandEventArgs e)
        {
           
                IBO objbo = new empbobject.clsbo();
                IBuisness objapp = new clsbuisness();
                if (e.CommandName == "new")
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView2.Rows[index];
                    string requestNo = row.Cells[2].Text;
                    objbo.idd = requestNo;
                    objbo.Status = "Approved";
                }

                else
                {
                    int index = Convert.ToInt32(e.CommandArgument);
                    GridViewRow row = GridView2.Rows[index];
                    string requestNo = row.Cells[2].Text;
                    objbo.idd = requestNo;
                    objbo.Status = "Rejected";
                }
                int result = objapp.CRstatus(objbo);
                if (result > 0)
                {
                    Response.Write("<script>alert('request " + objbo.Status + "')</script>");
                    bindgrid();
                }
            }
          
        

        protected void btn_ViewCR_Click(object sender, EventArgs e)
        {
            bindgrid();
        }
    }
    }
    
