﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empdal;
using System.Data;
using Types;

namespace empbusiness
{
  public  class clsbuisness:IBuisness
    {
        public DataTable Viewallstatus()
        {
            IDAL objdal = new clsdal();
            return objdal.Viewallstatus();
        }
        public string emplogin(ILOGINbo obj)
        {
            try
            {
                IDAL objdatalayer = new clsdal();
                return objdatalayer.emplogin(obj);
            }
            catch (Exception ex)
            {
                return null;
            }

        }
        public int verifyapplication(IBO objva)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.verifyapplication(objva);
        }
        public int srappstatus(IBO objbo)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.srappstatus(objbo);
        }
        public DataTable Viewall()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewall();

            return dt;
        }
        public DataTable Viewallsr()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewallsr();

            return dt;
        }
        
        public DataTable detailsviewapplication(string s)
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.detailsviewapplication(s);

            return dt;
        }
        public DataTable Viewfilter(IBO objj)
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewfilter(objj);

            return dt;
        }
        public DataTable Viewallcr()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.Viewallcr();

            return dt;
        }

        public int CRstatus(IBO objcr)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.CRstatus(objcr);
        }
        public DataTable viewchangereq()
        {
            DataTable dt;
            IDAL datalayer = new clsdal();
            dt = datalayer.viewchangereq();

            return dt;
        }
        public DataTable viewchangevalue(IBO objcv)
        {
            try
            {
                DataTable dt;
                IDAL dl = new clsdal();
                dt = dl.viewchangevalue(objcv);
                return dt;
            }
            catch (Exception ex)
            {
                return null;
                
            }
        }
        public int changecertificate(IBO obj)
        {
            IDAL objdatalayer = new clsdal();
            return objdatalayer.changecertificate(obj);

        }
        public DataTable viewcertificate(string username)
        {
            DataTable dt = new DataTable();
            IDAL dl = new clsdal();
            dt = dl.viewcertificate(username);
            return dt;
        }
        public DataTable all(string username)
        {
            DataTable dt = new DataTable();
            IDAL dl = new clsdal();
            dt = dl.all(username);
            return dt;
        }
        

    }
}