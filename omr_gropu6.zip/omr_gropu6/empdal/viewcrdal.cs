﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using empbobject;
using System.Data;
using System.Data.SqlClient;
using Types;
namespace empdal
{
    public class viewcrdal : IVIEWCRDAL
    {
        public DataTable viewall()
        {
            try
            { 
            string constr = "Data Source=inchnilpdb02\\mssqlserver1; Initial Catalog=CHN12_MMS73_Group6;User id=mms73group6; Password=mms73group6";
            SqlConnection con = new SqlConnection(constr);
            SqlCommand cmd = new SqlCommand("sp_viewcrr", con);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlDataAdapter da = new SqlDataAdapter();
            da.SelectCommand = cmd;
            DataSet ds = new DataSet();
            da.Fill(ds, "tbl_omr_g6_changerequest");
            return ds.Tables[0];
            }
            catch (Exception ex)
            {
                return null;
            }
        }
        public int forward(IVIEWCRBO bo)
        {
            try
            { 
            string constr = "Data Source=inchnilpdb02\\mssqlserver1; Initial Catalog=CHN12_MMS73_Group6;User id=mms73group6; Password=mms73group6";
            SqlConnection con = new SqlConnection(constr);
            con.Open();
            SqlCommand cmd = new SqlCommand("sp_forwardcr", con);
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.Parameters.AddWithValue("@application_no", bo.app_no);
            cmd.Parameters.AddWithValue("@remarks", bo.Remarks);
            int cnt = cmd.ExecuteNonQuery();
            return cnt;
            }
            catch (Exception ex)
            {
                return 0;
            }
        }
        public DataTable ViewbyCR(IVIEWCRBO bo)
        {
            DataTable dt = new DataTable();
            SqlConnection conn = new SqlConnection();

            try
            {
                System.Text.StringBuilder s = new System.Text.StringBuilder();
                s.AppendFormat("select distinct a.MgrLocation,c.Firstname as husbandname,d.Firstname as wifename,b.*,e.cr_id from tbl_omr_g6_application a,tbl_omr_g6_changevalue b,tbl_omr_g6_persondetails c,tbl_omr_g6_persondetails d,tbl_omr_g6_changerequest e where a.Application_no = b.application_no and a.Husbandid = c.Person_id and a.Wifeid = d.Person_id and b.cr_id=e.cr_id  and 1 = 1 ");
                //string check = bo.app_no.ToString();

                if (!String.IsNullOrEmpty(bo.app_no))
                {
                    s.AppendFormat(" AND a.application_no =" +bo.app_no+"  ");

                }
                else
                { }
                if (!String.IsNullOrEmpty(bo.hname))
                {
                    s.AppendFormat(" AND c.firstname ='" + bo.hname + "'");

                }
                if (!String.IsNullOrEmpty(bo.wname))
                {
                    s.AppendFormat(" AND d.firstname  ='" + bo.wname + "'");

                }
                if (!String.IsNullOrEmpty(bo.mrgeloc))
                {
                    s.AppendFormat(" AND Mgrlocation ='" + bo.mrgeloc + "'");

                }

                SqlDataAdapter da = new SqlDataAdapter();
                string d = s.ToString();
                string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_Group6;User ID=mms73group6;Password=mms73group6";
                //string str = @"Data Source=RISHU\SQLSERVER2;Initial Catalog=omr;User ID=sa;Password=pass";
                conn.ConnectionString = str;
                conn.Open();
                SqlCommand cmd = new SqlCommand();
                cmd.CommandText = d;
                cmd.CommandType = CommandType.Text;
                cmd.Connection = conn;
                da.SelectCommand = cmd;
                da.Fill(dt);
                conn.Close();
                return dt;
            }
            catch (Exception ex)
            {
                return null;
            }
            finally
            {
                if (conn.State == ConnectionState.Open)
                {
                    conn.Close();
                }
            }

        }
    }
}
