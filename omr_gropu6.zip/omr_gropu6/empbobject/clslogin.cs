﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
   public class clslogin:ILOGINbo
    {
        public string  pass;int user;
        public int Username
        {
            get { return user; }
            set { user = value; }
        }
        public string txtpwd

        {
            get { return pass ; }
            set { pass = value; }
        }
        public clslogin()
        {
        }
        public clslogin(int user1, string pass1)
        {
            user = user1;
            pass = pass1;
        }

    }
}
