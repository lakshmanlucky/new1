﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
    public class clsbo:IBO
    {
        int cr;
        int ApplicationNo;
        string HusbandId, WifeId,id;
        DateTime MarraigeDate;
        string Created_by, Modified_by;
        string MrgLocation, Address, District, State, Nationality, UserName, Husband, Wife;
        int Noofcopies;
        DateTime Created_Date, Modified_Date;
        public DateTime marg
        {
            get
            {
                return MarraigeDate;
            }
            set
            {
                MarraigeDate = value;
            }
        }
        public string username
        {
            get
            {
                return UserName;
            }
            set
            {
                UserName = value;
            }
        }
        public string location
        {
            get
            {
                return MrgLocation;
            }
            set
            {
                MrgLocation = value;
            }
        }
        public string husname
        {
            get
            {
                return Husband;
            }
            set
            {
                Husband = value;
            }

        }
        string statuss;
        public string Status
        {
            get { return statuss; }
            set { statuss = value; }
        }
        string remarkk;
        public string remark
        {
            get { return remarkk; }
            set { remarkk = value; }

        }
        public string wifename
        {
            get
            {
                return Wife;
            }
            set
            {
                Wife = value;
            }
        }
        public string wife
        {
            get
            {
                return WifeId;
            }
            set
            {
                WifeId = value;
            }
        }
        public string husband
        {
            get
            {
                return HusbandId;
            }
            set
            {
                HusbandId = value;
            }
        }
        public string idd
        {
            get
            {
                return id;
            }
            set
            {
                id = value;
            }
        }
        public int coopies
        {
            get
            {
                return Noofcopies;
            }
            set
            {
                Noofcopies = value;
            }
        }

        public int Cr
        {
            get
            {
                return cr;
            }

            set
            {
                cr = value;
            }
        }

        public clsbo()
        {
        }
        //ApplicationNo = idd;
        //MarraigeDate = marg;
        //MrgLocation = location;
        //Address = address;
        //District = district;
        //State = state;
        //Nationality = nationality;
        //UserName = username;
        //Noofcopies = coopies;
        //HusbandId = husband;
        //WifeId = wife;
        //Created_by = createdby;
        //Created_Date = created;
        //Modified_by = modifiedby;
        //Modified_Date = modified;
        public clsbo(int application, string husband, string wife, DateTime marriage, string loc)
        {
            ApplicationNo = application;
            marg = marriage;
            Husband = husband;
            Wife = wife;
            MrgLocation = loc;
        }

    }
}
