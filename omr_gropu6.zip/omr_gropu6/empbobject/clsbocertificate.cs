﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
   public class clsbocertificate:IBOCErtificate
    {
        string MrgLocation, address, district, state, nationality, userName, Husband, Wife,email;
        int contactno;
        DateTime date;
        public string location
        {
            get
            {
                return MrgLocation;
            }

            set
            {
                MrgLocation = value;
            }
        }

        public string Address1
        {
            get
            {
                return address;
            }

            set
            {
                address = value;
            }
        }

        public string District
        {
            get
            {
                return district;
            }

            set
            {
                district = value;
            }
        }

        public string State
        {
            get
            {
                return state;
            }

            set
            {
                state = value;
            }
        }

        public string Nationality
        {
            get
            {
                return nationality;
            }

            set
            {
                nationality = value;
            }
        }

        public string UserName
        {
            get
            {
                return userName;
            }

            set
            {
                userName = value;
            }
        }

        public string Husband1
        {
            get
            {
                return Husband;
            }

            set
            {
                Husband = value;
            }
        }

        public string Wife1
        {
            get
            {
                return Wife;
            }

            set
            {
                Wife = value;
            }
        }

        public string Email
        {
            get
            {
                return email;
            }

            set
            {
                email = value;
            }
        }

        public int Contactno
        {
            get
            {
                return contactno;
            }

            set
            {
                contactno = value;
            }
        }

        public DateTime Date
        {
            get
            {
                return date;
            }

            set
            {
                date = value;
            }
        }
     
        public clsbocertificate(string husband, string wife, DateTime marriage, string loc,string addresss,string districtt,string statee,string nationalityy)
        {
          
            Date = marriage;
            Husband1 = husband;
         Wife1 = wife;
            location = loc;
           Address1 = addresss;
          District = districtt;
            State = statee;
            Nationality = nationalityy;
        }
    }
}
