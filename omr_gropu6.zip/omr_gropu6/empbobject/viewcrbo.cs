﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Types;
namespace empbobject
{
    public class viewcrbo: IVIEWCRBO
    
    {
        String Application_no;
        DateTime MarraigeDate;
        string MgrLocation;
        string Husbandname;
        string Wifename;
        string remarks;
        int CR_ID;
        public string app_no
        {
            get { return Application_no; }
            set { Application_no = value; }
        }
        public DateTime mrgedate
        {
            get { return MarraigeDate; }
            set { MarraigeDate = value; }
        }
        public string mrgeloc
        {
            get { return MgrLocation; }
            set { MgrLocation = value; }
        }
        public string hname
        {
            get { return Husbandname; }
            set { Husbandname = value; }
        }
        public string wname
        {
            get { return Wifename; }
            set { Wifename = value; }
        }

        public string Remarks
        {
            get
            {
                return remarks;
            }

            set
            {
                remarks = value;
            }
        }
        public int cr_id
        {
            get { return CR_ID; }
            set { CR_ID = value; }
        }
        public viewcrbo()
        {

        }
        public viewcrbo(string Application_no,string remarks)
        {
            this.Application_no = Application_no;
            this.remarks = remarks;
        }
    }
}
