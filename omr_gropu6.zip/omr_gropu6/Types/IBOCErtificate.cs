﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
   public class IBOCErtificate
    {
        public string username { get; set; }
        public string location { get; set; }
        public string Huband1 { get; set; }
        public string Wife1 { get; set; }
 
      public DateTime Date { get; set; }
        public string Address1 { get; set; }
        public string District { get; set; }
        public string State { get; set; }
        public int Contactno { get; set; }
        public string Email { get; set; }
        public string Nationality { get; set; }
    }
}
