﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Types
{
    public interface IVIEWCRBO
    {
        string app_no { get; set; }
        DateTime mrgedate { get; set; }
        string mrgeloc { get; set; }
        string hname { get; set; }
        string wname { get; set; }
        string Remarks { get; set; }
    }
}
