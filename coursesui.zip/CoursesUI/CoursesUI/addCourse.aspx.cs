﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using BLL;


namespace CoursesUI
{
    public partial class addCourse : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            txtcategory.Value = Session["category"].ToString();

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            CoursesBO course = new CoursesBO();
            course.CourseName = txtname.Value.ToString();
            course.CourseDescription = txtdescription.Value.ToString();
            course.Mode = ddlmode.SelectedItem.ToString();
            course.Category = txtcategory.Value.ToString();
            CoursesBLL coursebll = new CoursesBLL();
            int result = coursebll.addCourse(course);
            if (result > 0)
            {
                Response.Write("<script>alert('DONE WITH COURSEID: " + result + "')</script>");
                //Response.Redirect("viewCourse.aspx");
            }
            else if (result == -2)
            {
                Response.Write("<script>alert('NOT DONE')</script>");


            }
            else
                Response.Write("<script>alert('DONE but id cannot be shown')</script>");

        }
    }
}