﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BO
{
    public class CoursesBO
    {
        int courseid;
        string courseName;
        string courseDescription;
        string mode;
        string category;

        public string CourseName
        {
            get
            {
                return courseName;
            }

            set
            {
                courseName = value;
            }
        }

        public string CourseDescription
        {
            get
            {
                return courseDescription;
            }

            set
            {
                courseDescription = value;
            }
        }

        public string Mode
        {
            get
            {
                return mode;
            }

            set
            {
                mode = value;
            }
        }

        public string Category
        {
            get
            {
                return category;
            }

            set
            {
                category = value;
            }
        }

        public int Courseid
        {
            get
            {
                return courseid;
            }

            set
            {
                courseid = value;
            }
        }

        public CoursesBO()
        {

        }
    }
}
