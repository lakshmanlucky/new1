﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;


namespace CoDAL
{
    public class CoursesDAL
    {
        public int addCourse(CoursesBO obj)
        {
            //string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //conn.ConnectionString = str;
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            int ret = 0;
            SqlDataAdapter adp = new SqlDataAdapter();
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_addcourse1185509", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ob = cmd.Parameters.Add("@courseid", SqlDbType.Int);
            cmd.Parameters.Add(new SqlParameter("@courseName", obj.CourseName));
            cmd.Parameters.Add(new SqlParameter("@courseDescription", obj.CourseDescription));
            cmd.Parameters.Add(new SqlParameter("@mode", obj.Mode));
            cmd.Parameters.Add(new SqlParameter("@category", obj.Category));
            ob.Direction = ParameterDirection.Output;
            adp.SelectCommand = cmd;
            conn.Open();

            ret = cmd.ExecuteNonQuery();
            conn.Close();

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            if (ret == 1)
            {
                return (int)ob.Value;

            }
            else
                return 0;

        }
        public DataTable viewCourse(CoursesBO obj)
        {
            //string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //conn.ConnectionString = str;
            SqlDataAdapter da = new SqlDataAdapter();
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            DataTable booktable = new DataTable();
            SqlCommand cmd = new SqlCommand();
            cmd.Connection = conn;
            da.SelectCommand = cmd;
            cmd.Parameters.Add(new SqlParameter("@category", obj.Category));
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "usp_viewcourse1185509";
            da.SelectCommand = cmd;
            da.Fill(booktable);
            conn.Close();
            return booktable;
        }
    }
}
