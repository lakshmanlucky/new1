﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data;
using CoDAL;



namespace BLL
{
    public class CoursesBLL
    {
        public int addCourse(CoursesBO obj)
        {
             CoursesDAL objclss = new CoursesDAL();

            return objclss.addCourse(obj);

        }
        public DataTable viewCourse(CoursesBO obj)
        {


            CoursesDAL objclss = new CoursesDAL();
            return objclss.viewCourse(obj);


        }
    }
}
