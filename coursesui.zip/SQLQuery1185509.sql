create table CourseDetails1185509
(
    courseid INT IDENTITY (1, 1)  primary key,
    coursename   VARCHAR (20) ,
    description1 VARCHAR (100) ,
    mode        VARCHAR (20) ,
    category    VARCHAR (20) ,
);

CREATE procedure usp_addcourse1185509(@courseid int out,@courseName varchar(20),
@courseDescription varchar(100),@mode varchar(20),@category varchar(20))
as
begin
 insert into CourseDetails1185509 values(@courseName,@courseDescription,@mode,@category)
 set @courseid=@@IDENTITY
end
CREATE procedure usp_viewcourse1185509(@category varchar(50))
as
begin
 select * from CourseDetails1185509  where category = @category
 end