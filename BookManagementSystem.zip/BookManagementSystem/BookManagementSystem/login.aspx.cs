﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Security;

namespace BookManagementSystem
{
    public partial class login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //Label1.Text = Session["id"].ToString();

        }

        protected void submit_Click(object sender, EventArgs e)
        {
            string name = txtname.Value.ToString();
            string word = txtpassword.Value.ToString(); 
            if (FormsAuthentication.Authenticate(name, word))
            {
                FormsAuthentication.RedirectFromLoginPage(name, false);
                Session["userid"] =txtname.Value.ToString();
                Session["time"] = DateTime.Now.ToString();
                Response.Redirect("bookdepository.aspx");
            }
            else
            {
                Response.Write("<script>alert('invalid user not autherized')</script>");
            }
        }
    }
}