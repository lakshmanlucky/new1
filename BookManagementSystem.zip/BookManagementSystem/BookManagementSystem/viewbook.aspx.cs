﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using BO;
using System.Web.Security;
using BLL;
using System.Data;
using System.Data.SqlClient;


namespace BookManagementSystem
{
    public partial class viewbook : System.Web.UI.Page
    {
        string str = @"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
      
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void Gr_RowCancelingEdit(object sender, GridViewCancelEditEventArgs e)
        {
            Gr.EditIndex = -1;
            gvbind();
        }
        protected void gvbind()
        {
            SqlConnection conn = new SqlConnection(str);
            conn.Open();
            SqlCommand cmd = new SqlCommand("Select * from dbo_BOOKDETAILS1185509", conn);
            SqlDataAdapter da = new SqlDataAdapter(cmd);
            DataSet ds = new DataSet();
            da.Fill(ds);
            conn.Close();
            if (ds.Tables[0].Rows.Count > 0)
            {
                Gr.DataSource = ds;
                Gr.DataBind();
            }
            else
            {
                ds.Tables[0].Rows.Add(ds.Tables[0].NewRow());
                Gr.DataSource = ds;
                Gr.DataBind();
                int columncount = Gr.Rows[0].Cells.Count;
                Gr.Rows[0].Cells.Clear();
                Gr.Rows[0].Cells.Add(new TableCell());
                Gr.Rows[0].Cells[0].ColumnSpan = columncount;
                Gr.Rows[0].Cells[0].Text = "No Records Found";
            }

        }
        protected void submit_Click(object sender, EventArgs e)
        {
           
            BookBO book = new BookBO();
            book.Category = txtname.Value.ToString();
            BookBLL bookbll = new BookBLL();
            
            Gr.DataSource = bookbll.viewBook(book);
            Gr.DataBind();
                Gr.Visible = true;
            
        }
        protected void Gr_RowDeleting(object sender, GridViewDeleteEventArgs e)
        {
            SqlConnection conn = new SqlConnection(str);
            GridViewRow row = (GridViewRow)Gr.Rows[e.RowIndex];
            Label lbldeleteid = (Label)row.FindControl("lblID");
            conn.Open();
            SqlCommand cmd = new SqlCommand("delete FROM dbo_BOOKDETAILS1185509 where bookid='" + Convert.ToInt32(Gr.DataKeys[e.RowIndex].Value.ToString()) + "'", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            gvbind();

        }
        protected void Gr_RowEditing(object sender, GridViewEditEventArgs e)
        {
            Gr.EditIndex = e.NewEditIndex;
            gvbind();
        }
        protected void Gr_RowUpdating(object sender, GridViewUpdateEventArgs e)
        {
            SqlConnection conn = new SqlConnection(str);

            int userid = Convert.ToInt32(Gr.DataKeys[e.RowIndex].Value.ToString());
            GridViewRow row = (GridViewRow)Gr.Rows[e.RowIndex];
            Label lblID = (Label)row.FindControl("lblID");
            //TextBox txtname=(TextBox)gr.cell[].control[];
            TextBox textName = (TextBox)row.Cells[1].Controls[0];
      
           // int i = Convert.ToInt32(textName);
            //TextBox textadd = (TextBox)row.FindControl("txtadd");
            //TextBox textc = (TextBox)row.FindControl("txtc");
            Gr.EditIndex = -1;
            conn.Open();
            //SqlCommand cmd = new SqlCommand("SELECT * FROM detail", conn);
            SqlCommand cmd = new SqlCommand("update dbo_BOOKDETAILS1185509 set bookname='" + textName.Text + "' where bookid='" + userid + "'", conn);
            cmd.ExecuteNonQuery();
            conn.Close();
            gvbind();
            //Gr.DataBind();
        }
    }
}