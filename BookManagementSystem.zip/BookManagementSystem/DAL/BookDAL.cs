﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using BO;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace DAL
{
    public class BookDAL
    {
        public int addBook(BookBO obj)
        {
            //string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //conn.ConnectionString = str;
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            int ret = 0;
            SqlDataAdapter adp = new SqlDataAdapter();
            int returnsrid = 0;
            SqlCommand cmd = new SqlCommand();
            cmd = new SqlCommand("usp_addbooks1185509", conn);
            cmd.CommandType = CommandType.StoredProcedure;
            SqlParameter ob = cmd.Parameters.Add("@BookID", SqlDbType.Int);
           // cmd.Parameters.AddWithValue("@BookID", 0);
            cmd.Parameters.Add(new SqlParameter("@BookName", obj.BookName));
            cmd.Parameters.Add(new SqlParameter("@Author", obj.Author));
            cmd.Parameters.Add(new SqlParameter("@Price", obj.Price));
             cmd.Parameters.Add(new SqlParameter("@Category", obj.Category));
            ob.Direction = ParameterDirection.Output;
           // returnsrid = Convert.ToInt32(new SqlParameter("@BookID", SqlDbType.Int));

            adp.SelectCommand = cmd;
            conn.Open();
            
            ret = cmd.ExecuteNonQuery();
            conn.Close();

            if (conn.State == ConnectionState.Open)
            {
                conn.Close();
            }
            if (ret == 1)
            {
                return (int)ob.Value;

            }
            else
                return 0;

        }
        public DataTable viewBook(BookBO obj)
        {
            //string str = ConfigurationManager.ConnectionStrings["conn"].ConnectionString;
            //conn.ConnectionString = str;
            SqlDataAdapter da = new SqlDataAdapter();
            SqlConnection conn = new SqlConnection(@"Data Source=inchnilpdb02\mssqlserver1;Initial Catalog=CHN12_MMS73_TEST;Integrated Security=False;User ID=mms73user;Password=mms73user;Connect Timeout=15;Encrypt=False;TrustServerCertificate=True;ApplicationIntent=ReadWrite;MultiSubnetFailover=False");
            DataTable booktable = new DataTable();
            SqlCommand cmd = new SqlCommand();
         
            cmd.Connection = conn;
            da.SelectCommand = cmd;
            cmd.Parameters.Add(new SqlParameter("@Category", obj.Category));
            cmd.CommandType = CommandType.StoredProcedure;
            cmd.CommandText = "usp_viewBook1185509";
            da.SelectCommand = cmd;
            da.Fill(booktable);
            conn.Close();
            return booktable;
        }
        public int deleteBook(BookBO obj)
        {

            return 0;

        }

    }
}
